"""Real PostgreSQL warehouse tests; run in the analytics-worker container."""

# ruff: noqa: E501
import importlib.util
import os
import sys
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import uuid4

import psycopg

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "analytics/ingestion-worker"))
SPEC = importlib.util.spec_from_file_location(
    "warehouse_worker", ROOT / "analytics/ingestion-worker/worker.py"
)
WORKER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(WORKER)
sys.path.insert(0, str(ROOT / "analytics/ingestion-worker"))
import backfill


class WarehouseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dsn = os.environ["WAREHOUSE_DSN"]
        with psycopg.connect(cls.dsn) as connection:
            WORKER.migrate(connection)

    def setUp(self):
        self.db = psycopg.connect(self.dsn)
        self.order = str(uuid4())
        self.stage = str(uuid4())
        self.team = "test-" + str(uuid4())
        self.now = datetime(2026, 11, 4, 12, tzinfo=timezone.utc)

    def tearDown(self):
        self.db.rollback()
        self.db.close()

    def event(self, kind, sequence=1, minutes=0, payload=None, stage=False, source=None):
        return {
            "eventId": str(uuid4()),
            "eventType": kind,
            "eventVersion": 1,
            "workOrderId": self.order,
            "workflowId": str(uuid4()),
            "stageInstanceId": self.stage if stage else None,
            "actorId": "synthetic-supervisor",
            "actorRole": "Supervisor",
            "sourceService": source or ("workflows" if stage else "work-orders"),
            "occurredAtUtc": (self.now + timedelta(minutes=minutes)).isoformat(),
            "recordedAtUtc": (self.now + timedelta(minutes=minutes)).isoformat(),
            "sequenceNumber": sequence,
            "eventPayload": {
                "teamId": self.team,
                "technicianId": "tech-" + self.order,
                "stageIndex": 0,
                **(payload or {}),
            },
            "schemaVersion": 1,
        }

    def test_duplicate_business_event_is_idempotent(self):
        event = self.event("WorkOrderCreated.v1", payload={"createdAtUtc": self.now.isoformat()})
        self.assertTrue(WORKER.project(self.db, event))
        self.assertFalse(WORKER.project(self.db, event))
        self.assertEqual(
            1,
            self.db.execute(
                "SELECT count(*) FROM warehouse.ingestion_ledger WHERE event_id=%s",
                (event["eventId"],),
            ).fetchone()[0],
        )

    def test_work_order_asset_reference_is_projected_and_preserved(self):
        asset = str(uuid4())
        created = self.event(
            "WorkOrderCreated.v1",
            payload={"createdAtUtc": self.now.isoformat(), "assetId": asset},
        )
        WORKER.project(self.db, created)
        self.assertEqual(
            asset,
            str(self.db.execute(
                "SELECT asset_reference FROM warehouse.fact_work_order WHERE work_order_id=%s",
                (self.order,),
            ).fetchone()[0]),
        )
        # A later update without assetId must not erase the existing link.
        updated = self.event(
            "WorkOrderUpdated.v1", sequence=2, minutes=5,
            payload={"createdAtUtc": self.now.isoformat(), "status": "Scheduled"},
        )
        WORKER.project(self.db, updated)
        self.assertEqual(
            asset,
            str(self.db.execute(
                "SELECT asset_reference FROM warehouse.fact_work_order WHERE work_order_id=%s",
                (self.order,),
            ).fetchone()[0]),
        )

    def test_archive_reconciliation_does_not_write_without_apply(self):
        event = self.event("WorkOrderCreated.v1")
        report = backfill.reconcile(self.db, [event, event])
        self.assertEqual((1, 1, 0), (report["missingBefore"], report["repeatedArchiveRows"], report["inserted"]))
        self.assertIsNone(self.db.execute("SELECT 1 FROM warehouse.ingestion_ledger WHERE event_id=%s", (event["eventId"],)).fetchone())

    def test_archive_backfill_is_idempotent_and_preserves_late_terminal_state(self):
        complete = self.event("WorkOrderCompleted.v1", sequence=3, minutes=50, payload={"completedAtUtc": (self.now + timedelta(minutes=50)).isoformat()})
        created = self.event("WorkOrderCreated.v1", payload={"createdAtUtc": self.now.isoformat(), "serviceCategory": "HVAC"})
        report = backfill.reconcile(self.db, [complete, created], apply=True)
        self.assertEqual(2, report["inserted"])
        self.assertEqual(0, backfill.reconcile(self.db, [complete, created], apply=True)["inserted"])
        self.assertEqual("Completed", self.db.execute("SELECT s.status FROM warehouse.fact_work_order f JOIN warehouse.dim_work_order_status s USING(status_key) WHERE f.work_order_id=%s", (self.order,)).fetchone()[0])

    def test_archive_collision_is_detected_before_any_missing_event_is_written(self):
        retained = self.event("WorkOrderCreated.v1")
        WORKER.project(self.db, retained)
        changed = {**retained, "eventPayload": {**retained["eventPayload"], "priority": "Critical"}}
        missing = self.event("WorkOrderUpdated.v1", sequence=2)
        with self.assertRaisesRegex(ValueError, "differs"):
            backfill.reconcile(self.db, [missing, changed], apply=True)
        self.assertIsNone(self.db.execute("SELECT 1 FROM warehouse.ingestion_ledger WHERE event_id=%s", (missing["eventId"],)).fetchone())

    def test_changed_duplicate_is_rejected(self):
        event = self.event("WorkOrderCreated.v1")
        WORKER.project(self.db, event)
        event["eventPayload"]["priority"] = "Critical"
        with self.assertRaisesRegex(ValueError, "identity collision"):
            WORKER.project(self.db, event)

    def test_late_stage_started_does_not_erase_completion_or_breach(self):
        common = {
            "startedAtUtc": self.now.isoformat(),
            "deadlineUtc": (self.now + timedelta(minutes=30)).isoformat(),
        }
        WORKER.project(
            self.db,
            self.event(
                "StageCompleted.v1",
                5,
                40,
                {
                    **common,
                    "completedAtUtc": (self.now + timedelta(minutes=40)).isoformat(),
                    "pausedSeconds": 120,
                    "status": "Completed",
                },
                True,
            ),
        )
        WORKER.project(
            self.db,
            self.event("StageSLABreached.v1", 3, 30, {**common, "slaStatus": "Breached"}, True),
        )
        WORKER.project(
            self.db, self.event("StageStarted.v1", 1, 0, {**common, "status": "Active"}, True)
        )
        row = self.db.execute(
            "SELECT status,breached,effective_minutes FROM analytics.v_stage_duration WHERE stage_instance_id=%s",
            (self.stage,),
        ).fetchone()
        self.assertEqual("Completed", row[0])
        self.assertTrue(row[1])
        self.assertAlmostEqual(38, float(row[2]))

    def test_late_order_creation_preserves_completed_state(self):
        WORKER.project(
            self.db,
            self.event(
                "WorkflowCompleted.v1",
                9,
                90,
                {"completedAtUtc": (self.now + timedelta(minutes=90)).isoformat()},
            ),
        )
        WORKER.project(
            self.db,
            self.event(
                "WorkOrderCreated.v1",
                1,
                0,
                {
                    "createdAtUtc": self.now.isoformat(),
                    "number": "SYNTH-1",
                    "serviceCategory": "HVAC",
                    "status": "Created",
                },
            ),
        )
        row = self.db.execute(
            "SELECT s.status,o.created_at_utc,o.completed_at_utc FROM warehouse.fact_work_order o JOIN warehouse.dim_work_order_status s USING(status_key) WHERE work_order_id=%s",
            (self.order,),
        ).fetchone()
        self.assertEqual("Completed", row[0])
        self.assertEqual(self.now, row[1])
        self.assertEqual(self.now + timedelta(minutes=90), row[2])

    def test_analytics_staging_excludes_customer_and_answers(self):
        event = self.event(
            "WorkOrderCreated.v1",
            payload={
                "customerName": "SYNTHETIC PRIVATE",
                "siteAddress": "PRIVATE",
                "answers": {"freeText": "PRIVATE"},
                "number": "SYNTH-2",
            },
        )
        WORKER.project(self.db, event)
        payload = self.db.execute(
            "SELECT safe_payload FROM warehouse.staging_event WHERE event_id=%s",
            (event["eventId"],),
        ).fetchone()[0]
        self.assertEqual("SYNTH-2", payload["number"])
        self.assertFalse({"customerName", "siteAddress", "answers"} & payload.keys())

    def test_unknown_schema_is_rejected_before_ledger_write(self):
        event = self.event("WorkOrderCreated.v1")
        event["schemaVersion"] = 2
        with self.assertRaisesRegex(ValueError, "Unsupported"):
            WORKER.project(self.db, event)
        self.assertEqual(
            0,
            self.db.execute(
                "SELECT count(*) FROM warehouse.ingestion_ledger WHERE event_id=%s",
                (event["eventId"],),
            ).fetchone()[0],
        )

    def test_booking_cancel_before_creation_remains_cancelled(self):
        booking_id = str(uuid4())
        WORKER.project(
            self.db,
            self.event("BookingCancelled.v1", 2, 2, {"id": booking_id, "technicianId": None}),
        )
        WORKER.project(
            self.db,
            self.event(
                "BookingCreated.v1",
                1,
                0,
                {
                    "id": booking_id,
                    "startUtc": self.now.isoformat(),
                    "endUtc": (self.now + timedelta(hours=1)).isoformat(),
                },
            ),
        )
        row = self.db.execute(
            "SELECT status,start_utc,end_utc,technician_key,source_version FROM warehouse.fact_booking WHERE booking_id=%s",
            (booking_id,),
        ).fetchone()
        self.assertEqual("Cancelled", row[0])
        self.assertEqual(self.now, row[1])
        self.assertEqual(self.now + timedelta(hours=1), row[2])
        self.assertIsNotNone(row[3])
        self.assertEqual(2, row[4])

    def test_late_work_order_metadata_cannot_replace_newer_source_version(self):
        WORKER.project(
            self.db,
            self.event(
                "WorkOrderUpdated.v1",
                4,
                10,
                {
                    "number": "LATEST",
                    "serviceCategory": "Cooling",
                    "priority": "Critical",
                    "status": "Cancelled",
                    "createdAtUtc": self.now.isoformat(),
                },
            ),
        )
        WORKER.project(
            self.db,
            self.event(
                "WorkOrderCreated.v1",
                1,
                0,
                {
                    "number": "OLD",
                    "serviceCategory": "HVAC",
                    "priority": "Normal",
                    "status": "Created",
                    "createdAtUtc": self.now.isoformat(),
                },
            ),
        )
        row = self.db.execute(
            "SELECT o.number,c.category,o.priority,s.status,o.order_source_sequence FROM warehouse.fact_work_order o JOIN warehouse.dim_service_category c USING(category_key) JOIN warehouse.dim_work_order_status s USING(status_key) WHERE work_order_id=%s",
            (self.order,),
        ).fetchone()
        self.assertEqual(("LATEST", "Cooling", "Critical", "Cancelled", 4), row)

    def test_different_service_sequence_does_not_order_work_order_metadata(self):
        WORKER.project(
            self.db,
            self.event("StageStarted.v1", 99, 30, {"startedAtUtc": self.now.isoformat()}, True),
        )
        WORKER.project(
            self.db,
            self.event(
                "WorkOrderUpdated.v1",
                2,
                5,
                {"number": "SOURCE-2", "priority": "High", "createdAtUtc": self.now.isoformat()},
            ),
        )
        self.assertEqual(
            ("SOURCE-2", "High", 2),
            self.db.execute(
                "SELECT number,priority,order_source_sequence FROM warehouse.fact_work_order WHERE work_order_id=%s",
                (self.order,),
            ).fetchone(),
        )

    def test_booking_workflow_and_completion_lifecycle_are_projected(self):
        WORKER.project(
            self.db,
            self.event("WorkOrderCreated.v1", payload={"createdAtUtc": self.now.isoformat()}),
        )
        booking_id = str(uuid4())
        WORKER.project(
            self.db,
            self.event(
                "BookingCreated.v1",
                payload={
                    "id": booking_id,
                    "startUtc": self.now.isoformat(),
                    "endUtc": (self.now + timedelta(hours=1)).isoformat(),
                },
                source="scheduling",
            ),
        )

        def status():
            return self.db.execute(
                "SELECT s.status FROM warehouse.fact_work_order o JOIN warehouse.dim_work_order_status s USING(status_key) WHERE work_order_id=%s",
                (self.order,),
            ).fetchone()[0]

        self.assertEqual("Scheduled", status())
        WORKER.project(self.db, self.event("WorkflowStarted.v1", source="workflows"))
        self.assertEqual("InProgress", status())
        WORKER.project(
            self.db,
            self.event("WorkOrderCreated.v1", payload={"createdAtUtc": self.now.isoformat()}),
        )
        self.assertEqual("InProgress", status())
        WORKER.project(self.db, self.event("WorkflowCompleted.v1", 9, 60, source="workflows"))
        WORKER.project(
            self.db,
            self.event("BookingCancelled.v1", 2, 61, {"id": booking_id}, source="scheduling"),
        )
        self.assertEqual("Completed", status())

    def test_late_booking_metadata_cannot_overwrite_rescheduled_interval(self):
        booking_id = str(uuid4())
        WORKER.project(
            self.db,
            self.event(
                "BookingRescheduled.v1",
                3,
                1,
                {
                    "id": booking_id,
                    "startUtc": (self.now + timedelta(hours=2)).isoformat(),
                    "endUtc": (self.now + timedelta(hours=3)).isoformat(),
                },
                source="scheduling",
            ),
        )
        WORKER.project(
            self.db,
            self.event(
                "BookingCreated.v1",
                1,
                0,
                {
                    "id": booking_id,
                    "startUtc": self.now.isoformat(),
                    "endUtc": (self.now + timedelta(hours=1)).isoformat(),
                },
                source="scheduling",
            ),
        )
        self.assertEqual(
            (self.now + timedelta(hours=2), self.now + timedelta(hours=3)),
            self.db.execute(
                "SELECT start_utc,end_utc FROM warehouse.fact_booking WHERE booking_id=%s",
                (booking_id,),
            ).fetchone(),
        )

    def publish_hours(self, start=8, end=17, zone="UTC", sequence=1, minutes=0):
        event = self.event(
            "TechnicianAvailabilityChanged.v1",
            sequence,
            minutes,
            payload={"workingStartHour": start, "workingEndHour": end, "timeZone": zone},
            source="technicians",
        )
        event["workOrderId"] = "00000000-0000-0000-0000-000000000000"
        WORKER.project(self.db, event)

    def publish_time_off(self, start, end, minutes=0, time_off_id=None, sequence=1):
        event = self.event(
            "TechnicianTimeOffChanged.v1",
            sequence,
            minutes,
            payload={"timeOffId": time_off_id or str(uuid4()), "startUtc": start.isoformat(), "endUtc": end.isoformat()},
            source="technicians",
        )
        event["workOrderId"] = "00000000-0000-0000-0000-000000000000"
        WORKER.project(self.db, event)
        return event

    def utilization(self, start, end, team=None, technician=None, include_weekends=False):
        return self.db.execute(
            "SELECT technician_id,booked_minutes,capacity_minutes,utilization FROM analytics.technician_utilization(%s,%s,%s,false,%s,NULL,NULL,%s)",
            (start, end, team or self.team, technician or "tech-" + self.order, include_weekends),
        ).fetchall()

    def test_technician_working_hours_use_own_latest_sequence(self):
        self.publish_hours(6, 14, "America/New_York", 3)
        self.publish_hours(8, 17, "UTC", 1)
        row = self.db.execute(
            "SELECT working_start_hour,working_end_hour,time_zone,working_minutes_per_day,source_sequence FROM warehouse.dim_technician WHERE technician_id=%s AND is_current",
            ("tech-" + self.order,),
        ).fetchone()
        self.assertEqual((6, 14, "America/New_York", 480, 3), row)

    def test_utilization_clips_bookings_and_includes_orders_created_before_range(self):
        self.publish_hours()
        WORKER.project(
            self.db,
            self.event(
                "WorkOrderCreated.v1",
                payload={"createdAtUtc": (self.now - timedelta(days=2)).isoformat()},
            ),
        )
        WORKER.project(
            self.db,
            self.event(
                "BookingCreated.v1",
                payload={
                    "id": str(uuid4()),
                    "startUtc": (self.now + timedelta(hours=1)).isoformat(),
                    "endUtc": (self.now + timedelta(hours=3)).isoformat(),
                },
                source="scheduling",
            ),
        )
        row = self.utilization(self.now + timedelta(minutes=90), self.now + timedelta(minutes=150))[
            0
        ]
        self.assertEqual((60.0, 60.0, 1.0), row[1:])

    def test_utilization_boundaries_are_half_open_and_team_scoped(self):
        self.publish_hours()
        WORKER.project(
            self.db,
            self.event(
                "BookingCreated.v1",
                payload={
                    "id": str(uuid4()),
                    "startUtc": self.now.isoformat(),
                    "endUtc": (self.now + timedelta(hours=1)).isoformat(),
                },
                source="scheduling",
            ),
        )
        row = self.utilization(self.now + timedelta(hours=1), self.now + timedelta(hours=2))[0]
        self.assertEqual((0.0, 60.0, 0.0), row[1:])
        self.assertEqual(
            [], self.utilization(self.now, self.now + timedelta(hours=1), "another-team")
        )

    def test_local_working_shift_capacity_handles_dst_and_session_timezone(self):
        self.publish_hours(0, 4, "America/New_York", minutes=-4 * 24 * 60)
        self.db.execute("SET LOCAL TIME ZONE 'Pacific/Auckland'")
        # Nov 1, 2026 repeats one hour in New York: 00:00-04:00 is five actual hours.
        start = datetime(2026, 11, 1, 4, tzinfo=timezone.utc)
        row = self.utilization(start, start + timedelta(hours=5), include_weekends=True)[0]
        self.assertEqual(300.0, row[2])
        self.assertEqual(0.0, row[3])

    def test_scd2_versions_are_contiguous_and_only_one_is_current(self):
        self.publish_hours(8, 17, "UTC", sequence=1, minutes=-60)
        self.publish_hours(9, 18, "UTC", sequence=2)
        rows = self.db.execute(
            "SELECT working_start_hour,working_end_hour,is_current,effective_to_utc FROM warehouse.dim_technician WHERE technician_id=%s ORDER BY effective_from_utc",
            ("tech-" + self.order,),
        ).fetchall()
        self.assertEqual(2, len(rows))
        self.assertEqual((8, 17, False, self.now), rows[0])
        self.assertEqual((9, 18, True, None), rows[1])
        self.assertEqual(
            1,
            self.db.execute(
                "SELECT count(*) FROM warehouse.dim_technician WHERE technician_id=%s AND is_current",
                ("tech-" + self.order,),
            ).fetchone()[0],
        )

    def test_late_technician_change_splits_history_without_multiple_current_rows(self):
        self.publish_hours(10, 18, "UTC", sequence=2)
        self.publish_hours(9, 17, "UTC", sequence=1, minutes=-60)
        rows = self.db.execute(
            "SELECT working_start_hour,effective_from_utc,effective_to_utc,is_current FROM warehouse.dim_technician WHERE technician_id=%s ORDER BY effective_from_utc",
            ("tech-" + self.order,),
        ).fetchall()
        self.assertEqual(2, len(rows))
        self.assertEqual((9, self.now - timedelta(minutes=60), self.now, False), rows[0])
        self.assertEqual((10, self.now, None, True), rows[1])
        self.assertFalse(
            self.db.execute(
                "SELECT EXISTS(SELECT 1 FROM warehouse.dim_technician a JOIN warehouse.dim_technician b ON a.technician_id=b.technician_id AND a.technician_key<b.technician_key AND a.effective_from_utc<b.effective_to_utc AND b.effective_from_utc<a.effective_to_utc WHERE a.technician_id=%s)",
                ("tech-" + self.order,),
            ).fetchone()[0]
        )

    def test_time_off_and_weekends_reduce_capacity_without_negative_utilization(self):
        monday = datetime(2026, 11, 2, tzinfo=timezone.utc)
        self.publish_hours(8, 17, "UTC", minutes=-5 * 24 * 60)
        self.publish_time_off(monday + timedelta(hours=10), monday + timedelta(hours=12))
        rows = self.db.execute(
            "SELECT technician_id,booked_minutes,capacity_minutes,utilization FROM analytics.technician_utilization(%s,%s,%s,false,%s,NULL,NULL)",
            (monday, monday + timedelta(days=5), self.team, "tech-" + self.order),
        ).fetchall()
        self.assertEqual(1, len(rows))
        self.assertEqual(0.0, rows[0][1])
        # Mon-Fri = five 9-hour shifts; Saturday is excluded; two hours are time off.
        self.assertEqual(2580.0, rows[0][2])
        self.assertEqual(0.0, rows[0][3])

    def test_late_time_off_change_cannot_overwrite_newer_interval(self):
        time_off_id = str(uuid4())
        newer_start = self.now + timedelta(days=2)
        older_start = self.now + timedelta(days=1)
        self.publish_time_off(
            newer_start, newer_start + timedelta(hours=2), time_off_id=time_off_id, sequence=2
        )
        self.publish_time_off(
            older_start, older_start + timedelta(hours=1), time_off_id=time_off_id, sequence=1
        )
        self.assertEqual(
            (newer_start, newer_start + timedelta(hours=2), 2),
            self.db.execute(
                "SELECT start_utc,end_utc,source_sequence FROM warehouse.fact_technician_time_off WHERE time_off_id=%s",
                (time_off_id,),
            ).fetchone(),
        )

    def test_scd2_database_exclusion_rejects_overlapping_versions(self):
        self.publish_hours(8, 17, "UTC", sequence=1, minutes=-60)
        with self.assertRaises(psycopg.errors.ExclusionViolation):
            self.db.execute(
                """INSERT INTO warehouse.dim_technician(technician_id,team_id,effective_from_utc,effective_to_utc,is_current,capacity_authoritative,working_start_hour,working_end_hour,time_zone)
                VALUES(%s,'north',%s,%s,false,true,8,17,'UTC')""",
                ("tech-" + self.order, self.now - timedelta(minutes=30), self.now + timedelta(minutes=30)),
            )

    def test_time_off_projection_deduplicates_and_excludes_reason(self):
        start = self.now + timedelta(days=1)
        event = self.publish_time_off(start, start + timedelta(hours=2))
        self.assertFalse(WORKER.project(self.db, event))
        safe = self.db.execute(
            "SELECT safe_payload FROM warehouse.staging_event WHERE event_id=%s", (event["eventId"],)
        ).fetchone()[0]
        self.assertNotIn("reason", safe)
        self.assertEqual(
            1,
            self.db.execute(
                "SELECT count(*) FROM warehouse.fact_technician_time_off WHERE technician_id=%s",
                ("tech-" + self.order,),
            ).fetchone()[0],
        )

    def test_unknown_timezone_or_open_range_has_no_invented_capacity(self):
        self.publish_hours(zone="Unknown/NotAZone")
        row = self.utilization(self.now, self.now + timedelta(hours=1))[0]
        self.assertIsNone(row[2])
        self.assertIsNone(row[3])
        self.publish_hours(sequence=2)
        row = self.utilization(None, self.now + timedelta(hours=1))[0]
        self.assertIsNone(row[2])
        self.assertIsNone(row[3])

    def test_missing_stage_start_is_unknown_duration_instead_of_zero(self):
        WORKER.project(
            self.db,
            self.event(
                "StageCompleted.v1",
                3,
                30,
                {"completedAtUtc": (self.now + timedelta(minutes=30)).isoformat()},
                True,
            ),
        )
        self.assertIsNone(
            self.db.execute(
                "SELECT effective_minutes FROM analytics.v_stage_duration WHERE stage_instance_id=%s",
                (self.stage,),
            ).fetchone()[0]
        )

    def test_migration_ledger_prevents_repeated_backfill(self):
        WORKER.project(
            self.db,
            self.event(
                "WorkOrderUpdated.v1",
                4,
                10,
                {"number": "KEEP", "createdAtUtc": self.now.isoformat()},
            ),
        )
        migration_count = self.db.execute(
            "SELECT count(*) FROM warehouse.schema_migration"
        ).fetchone()[0]
        WORKER.migrate(self.db)
        self.assertEqual(
            ("KEEP", 4),
            self.db.execute(
                "SELECT number,order_source_sequence FROM warehouse.fact_work_order WHERE work_order_id=%s",
                (self.order,),
            ).fetchone(),
        )
        self.assertEqual(
            migration_count,
            self.db.execute("SELECT count(*) FROM warehouse.schema_migration").fetchone()[0],
        )

    def test_late_warning_cannot_downgrade_critical_server_sla_status(self):
        WORKER.project(self.db, self.event("StageCriticalWarningRaised.v1", 3, 25, {}, True))
        WORKER.project(self.db, self.event("StageWarningRaised.v1", 2, 20, {}, True))
        self.assertEqual(
            "Critical",
            self.db.execute(
                "SELECT sla_status FROM warehouse.fact_workflow_stage WHERE stage_instance_id=%s",
                (self.stage,),
            ).fetchone()[0],
        )

    def test_utc_date_bucketing_ignores_database_session_timezone(self):
        created = datetime(2026, 11, 4, 23, 30, tzinfo=timezone.utc)
        WORKER.project(
            self.db,
            self.event("WorkOrderCreated.v1", payload={"createdAtUtc": created.isoformat()}),
        )
        self.db.execute("SET LOCAL TIME ZONE 'Pacific/Auckland'")
        date = self.db.execute(
            "SELECT (created_at_utc AT TIME ZONE 'UTC')::date FROM warehouse.fact_work_order WHERE work_order_id=%s",
            (self.order,),
        ).fetchone()[0]
        self.assertEqual(created.date(), date)

    def test_known_metric_grain_and_denominators(self):
        WORKER.project(
            self.db,
            self.event(
                "WorkOrderCreated.v1",
                payload={"createdAtUtc": self.now.isoformat(), "serviceCategory": "HVAC"},
            ),
        )
        WORKER.project(
            self.db,
            self.event(
                "StageCompleted.v1",
                4,
                40,
                {
                    "startedAtUtc": self.now.isoformat(),
                    "completedAtUtc": (self.now + timedelta(minutes=40)).isoformat(),
                    "status": "Completed",
                },
                True,
            ),
        )
        WORKER.project(self.db, self.event("StageSLABreached.v1", 3, 30, {}, True))
        WORKER.project(self.db, self.event("WorkflowCompleted.v1", 8, 60))
        row = self.db.execute(
            "SELECT total_work_orders,completed_work_orders,completion_rate,sla_compliance_rate,average_service_minutes,average_stage_minutes FROM analytics.v_team_summary WHERE team_id=%s",
            (self.team,),
        ).fetchone()
        self.assertEqual((1, 1, 1.0, 0.0), row[:4])
        self.assertEqual(60, float(row[4]))
        self.assertEqual(40, float(row[5]))

    def test_completion_without_creation_metadata_cannot_inflate_cohort_rate(self):
        WORKER.project(
            self.db,
            self.event("WorkOrderCreated.v1", payload={"createdAtUtc": self.now.isoformat()}),
        )
        self.order = str(uuid4())
        WORKER.project(self.db, self.event("WorkflowCompleted.v1", 9, 60, source="workflows"))
        row = self.db.execute(
            "SELECT total_work_orders,completed_work_orders,completion_rate FROM analytics.v_team_summary WHERE team_id=%s",
            (self.team,),
        ).fetchone()
        self.assertEqual((1, 0, 0.0), row)


if __name__ == "__main__":
    unittest.main()
